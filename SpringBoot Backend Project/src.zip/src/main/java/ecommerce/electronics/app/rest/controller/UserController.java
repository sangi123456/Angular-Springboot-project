package ecommerce.electronics.app.rest.controller;

public class UserController {

}
